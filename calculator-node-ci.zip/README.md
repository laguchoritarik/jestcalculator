# Calculator Node CI

This is a minimal Node.js project with Jest tests and GitHub Actions for CI.

## Run tests locally

```bash
npm test
```
